"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import {
  Upload,
  Users,
  Star,
  ArrowRight,
  Droplets,
  Sun,
  Shield,
  Heart,
  Facebook,
  Twitter,
  Instagram,
  Mail,
  Phone,
  MapPin,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function DermaHubLanding() {
  const [skinType, setSkinType] = useState("")
  const [skinConcerns, setSkinConcerns] = useState<string[]>([])
  const [sensitivity, setSensitivity] = useState([3])
  const [age, setAge] = useState("")

  const handleConcernToggle = (concern: string) => {
    setSkinConcerns((prev) => (prev.includes(concern) ? prev.filter((c) => c !== concern) : [...prev, concern]))
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                DermaHub
              </span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link href="#home" className="text-gray-700 hover:text-pink-600 transition-colors">
                Home
              </Link>
              <Link href="#about" className="text-gray-700 hover:text-pink-600 transition-colors">
                About Us
              </Link>
              <Link href="#features" className="text-gray-700 hover:text-pink-600 transition-colors">
                Features
              </Link>
              <Link href="#community" className="text-gray-700 hover:text-pink-600 transition-colors">
                Community
              </Link>
              <Link href="#contact" className="text-gray-700 hover:text-pink-600 transition-colors">
                Contact
              </Link>
            </nav>
            <Button className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
              Sign Up
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Discover Your Perfect{" "}
              <span className="bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                Skincare Routine
              </span>{" "}
              with DermaHub
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Personalized recommendations for every skin type. Join thousands who have transformed their skin with our
              AI-powered skincare guidance.
            </p>
            <Button
              size="lg"
              className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-lg px-8 py-3"
            >
              Get Started
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
          <div className="mt-16">
            <Image
              src="/placeholder.svg?height=400&width=800"
              alt="DermaHub skincare dashboard"
              width={800}
              height={400}
              className="mx-auto rounded-2xl shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* Interactive Skin Assessment */}
      <section id="assessment" className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Find Your Skin Type</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Understanding your skin type is the first step to achieving healthy, glowing skin. Our interactive
              assessment helps you identify your unique skin characteristics.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="p-8">
              <CardHeader>
                <CardTitle className="text-2xl text-center">Personalized Skin Assessment</CardTitle>
                <CardDescription className="text-center">
                  Answer a few questions to get your customized skincare recommendations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-8">
                {/* Skin Type Selection */}
                <div>
                  <label className="text-lg font-semibold mb-4 block">What's your primary skin type?</label>
                  <Select value={skinType} onValueChange={setSkinType}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select your skin type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="oily">
                        <div className="flex items-center space-x-2">
                          <Droplets className="w-4 h-4 text-blue-500" />
                          <span>Oily - Shiny, enlarged pores</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="dry">
                        <div className="flex items-center space-x-2">
                          <Sun className="w-4 h-4 text-yellow-500" />
                          <span>Dry - Tight, flaky skin</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="combination">
                        <div className="flex items-center space-x-2">
                          <Shield className="w-4 h-4 text-green-500" />
                          <span>Combination - Oily T-zone, dry cheeks</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="sensitive">
                        <div className="flex items-center space-x-2">
                          <Heart className="w-4 h-4 text-red-500" />
                          <span>Sensitive - Easily irritated</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Skin Concerns */}
                <div>
                  <label className="text-lg font-semibold mb-4 block">What are your main skin concerns?</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {["Acne", "Dark Spots", "Fine Lines", "Dullness", "Large Pores", "Redness"].map((concern) => (
                      <Badge
                        key={concern}
                        variant={skinConcerns.includes(concern) ? "default" : "outline"}
                        className={`cursor-pointer p-3 text-center justify-center ${
                          skinConcerns.includes(concern)
                            ? "bg-gradient-to-r from-pink-500 to-purple-600"
                            : "hover:bg-pink-50"
                        }`}
                        onClick={() => handleConcernToggle(concern)}
                      >
                        {concern}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Sensitivity Level */}
                <div>
                  <label className="text-lg font-semibold mb-4 block">
                    How sensitive is your skin? ({sensitivity[0]}/5)
                  </label>
                  <Slider
                    value={sensitivity}
                    onValueChange={setSensitivity}
                    max={5}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-500 mt-2">
                    <span>Not sensitive</span>
                    <span>Very sensitive</span>
                  </div>
                </div>

                {/* Age Range */}
                <div>
                  <label className="text-lg font-semibold mb-4 block">What's your age range?</label>
                  <Select value={age} onValueChange={setAge}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select your age range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="teens">Teens (13-19)</SelectItem>
                      <SelectItem value="twenties">20s</SelectItem>
                      <SelectItem value="thirties">30s</SelectItem>
                      <SelectItem value="forties">40s</SelectItem>
                      <SelectItem value="fifties">50s+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Photo Upload */}
                <div>
                  <label className="text-lg font-semibold mb-4 block">
                    Upload a photo for more accurate analysis (optional)
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-pink-400 transition-colors cursor-pointer">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Click to upload or drag and drop</p>
                    <p className="text-sm text-gray-400 mt-2">PNG, JPG up to 10MB</p>
                  </div>
                </div>

                <Button
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-lg py-3"
                  disabled={!skinType}
                >
                  Get My Personalized Recommendations
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="features" className="py-20 px-4 bg-gradient-to-r from-pink-50 to-purple-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Three simple steps to transform your skincare routine
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Select Your Skin Type</h3>
              <p className="text-gray-600">
                Complete our comprehensive skin assessment to identify your unique skin characteristics and concerns.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Receive Personalized Recommendations</h3>
              <p className="text-gray-600">
                Get AI-powered product recommendations and routines tailored specifically to your skin's needs.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Join Our Community</h3>
              <p className="text-gray-600">
                Connect with others on similar skincare journeys and share your progress with our supportive community.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Community Highlight */}
      <section id="community" className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              See how DermaHub has transformed the skincare routines of thousands of users
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <Image
                    src="/placeholder.svg?height=50&width=50"
                    alt="Sarah M."
                    width={50}
                    height={50}
                    className="rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-semibold">Sarah M.</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 mb-4">
                  "DermaHub completely changed my skincare game! The personalized recommendations cleared my acne in
                  just 6 weeks."
                </p>
                <Badge variant="outline" className="text-pink-600 border-pink-200">
                  Acne-prone skin
                </Badge>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <Image
                    src="/placeholder.svg?height=50&width=50"
                    alt="Michael R."
                    width={50}
                    height={50}
                    className="rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-semibold">Michael R.</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 mb-4">
                  "As a guy new to skincare, DermaHub made it so simple. My skin has never looked better, and I finally
                  understand what products work for me."
                </p>
                <Badge variant="outline" className="text-purple-600 border-purple-200">
                  Combination skin
                </Badge>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <Image
                    src="/placeholder.svg?height=50&width=50"
                    alt="Emma L."
                    width={50}
                    height={50}
                    className="rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-semibold">Emma L.</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 mb-4">
                  "The community support is amazing! I love sharing my progress and getting tips from others with
                  sensitive skin like mine."
                </p>
                <Badge variant="outline" className="text-red-600 border-red-200">
                  Sensitive skin
                </Badge>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <div className="flex items-center justify-center space-x-8 text-gray-600">
              <div className="flex items-center">
                <Users className="w-6 h-6 mr-2 text-pink-500" />
                <span className="text-lg font-semibold">50,000+ Happy Users</span>
              </div>
              <div className="flex items-center">
                <Star className="w-6 h-6 mr-2 text-yellow-500 fill-current" />
                <span className="text-lg font-semibold">4.9/5 Rating</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-pink-500 to-purple-600">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Transform Your Skin?</h2>
          <p className="text-xl text-pink-100 mb-8 max-w-2xl mx-auto">
            Join thousands of users who have discovered their perfect skincare routine with DermaHub
          </p>
          <Button size="lg" className="bg-white text-pink-600 hover:bg-gray-100 text-lg px-8 py-3">
            Start Your Journey Today
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-gray-900 text-white py-16 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                  <Heart className="w-5 h-5 text-white" />
                </div>
                <span className="text-2xl font-bold">DermaHub</span>
              </div>
              <p className="text-gray-400 mb-4">
                Personalized skincare recommendations powered by AI and community wisdom.
              </p>
              <div className="flex space-x-4">
                <Facebook className="w-5 h-5 text-gray-400 hover:text-pink-400 cursor-pointer" />
                <Twitter className="w-5 h-5 text-gray-400 hover:text-pink-400 cursor-pointer" />
                <Instagram className="w-5 h-5 text-gray-400 hover:text-pink-400 cursor-pointer" />
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#home" className="hover:text-pink-400">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="#about" className="hover:text-pink-400">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#features" className="hover:text-pink-400">
                    Features
                  </Link>
                </li>
                <li>
                  <Link href="#community" className="hover:text-pink-400">
                    Community
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/privacy" className="hover:text-pink-400">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-pink-400">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/cookies" className="hover:text-pink-400">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-3 text-gray-400">
                <div className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  <span>hello@dermahub.com</span>
                </div>
                <div className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" />
                  <span>San Francisco, CA</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} DermaHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
