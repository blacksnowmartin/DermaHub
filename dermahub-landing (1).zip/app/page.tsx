"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  MessageCircle,
  Sparkles,
  Clock,
  CheckCircle,
  ArrowRight,
  Heart,
  Droplets,
  Sun,
  Shield,
  Leaf,
  Star,
} from "lucide-react"
import Image from "next/image"

interface SkinType {
  id: string
  name: string
  label: string
  icon: React.ReactNode
  description: string
  characteristics: string[]
  routine: {
    morning: string[]
    evening: string[]
  }
  products: {
    name: string
    type: string
    rating: number
  }[]
}

const skinTypes: SkinType[] = [
  {
    id: "oily",
    name: "Oily Skin",
    label: "Oily",
    icon: <Droplets className="w-5 h-5" />,
    description: "Your skin produces excess sebum, giving it a shiny appearance with enlarged pores.",
    characteristics: ["Shiny T-zone", "Enlarged pores", "Prone to blackheads", "Makeup doesn't last long"],
    routine: {
      morning: ["Gentle foaming cleanser", "Niacinamide serum", "Oil-free moisturizer", "Broad-spectrum SPF"],
      evening: ["Double cleanse", "BHA exfoliant (2-3x/week)", "Retinol (start slowly)", "Lightweight night cream"],
    },
    products: [
      { name: "CeraVe Foaming Facial Cleanser", type: "Cleanser", rating: 4.5 },
      { name: "The Ordinary Niacinamide 10%", type: "Serum", rating: 4.3 },
      { name: "Neutrogena Oil-Free Moisture Gel", type: "Moisturizer", rating: 4.2 },
    ],
  },
  {
    id: "dry",
    name: "Dry Skin",
    label: "Dry",
    icon: <Sun className="w-5 h-5" />,
    description: "Your skin lacks moisture and natural oils, often feeling tight and rough.",
    characteristics: ["Tight feeling", "Flaky patches", "Fine lines", "Dull appearance"],
    routine: {
      morning: ["Cream cleanser", "Hyaluronic acid serum", "Rich moisturizer", "SPF with moisturizing base"],
      evening: ["Oil cleanser", "Gentle exfoliant (1-2x/week)", "Face oil", "Heavy night cream"],
    },
    products: [
      { name: "Cetaphil Gentle Skin Cleanser", type: "Cleanser", rating: 4.4 },
      { name: "The Ordinary Hyaluronic Acid", type: "Serum", rating: 4.6 },
      { name: "Olay Regenerist Micro-Sculpting Cream", type: "Moisturizer", rating: 4.3 },
    ],
  },
  {
    id: "combination",
    name: "Combination Skin",
    label: "Combination",
    icon: <Shield className="w-5 h-5" />,
    description: "Your T-zone is oily while your cheeks and other areas are normal to dry.",
    characteristics: ["Oily T-zone", "Normal/dry cheeks", "Mixed texture", "Seasonal changes"],
    routine: {
      morning: ["Gentle gel cleanser", "Vitamin C serum", "Lightweight moisturizer", "Broad-spectrum SPF"],
      evening: ["Micellar water + cleanser", "Targeted treatments", "Different moisturizers for different areas"],
    },
    products: [
      { name: "La Roche-Posay Effaclar Gel", type: "Cleanser", rating: 4.4 },
      { name: "Skinceuticals CE Ferulic", type: "Serum", rating: 4.7 },
      { name: "Clinique Dramatically Different Gel", type: "Moisturizer", rating: 4.1 },
    ],
  },
  {
    id: "sensitive",
    name: "Sensitive Skin",
    label: "Sensitive",
    icon: <Heart className="w-5 h-5" />,
    description: "Your skin reacts easily to products and environmental factors, often showing redness.",
    characteristics: ["Easily irritated", "Redness", "Burning sensation", "Reactive to products"],
    routine: {
      morning: ["Gentle, fragrance-free cleanser", "Calming serum", "Barrier repair moisturizer", "Mineral SPF"],
      evening: ["Same gentle cleanser", "Minimal products", "Rich, soothing moisturizer"],
    },
    products: [
      { name: "Vanicream Gentle Facial Cleanser", type: "Cleanser", rating: 4.5 },
      { name: "Avène Thermal Spring Water", type: "Mist", rating: 4.3 },
      { name: "CeraVe PM Facial Moisturizing Lotion", type: "Moisturizer", rating: 4.4 },
    ],
  },
  {
    id: "normal",
    name: "Normal Skin",
    label: "Normal",
    icon: <Leaf className="w-5 h-5" />,
    description: "Your skin is well-balanced with minimal concerns and good texture.",
    characteristics: ["Balanced oil production", "Small pores", "Good elasticity", "Even tone"],
    routine: {
      morning: ["Gentle cleanser", "Antioxidant serum", "Moisturizer", "SPF"],
      evening: ["Cleanser", "Retinol (2-3x/week)", "Moisturizer", "Face oil (optional)"],
    },
    products: [
      { name: "Fresh Soy Face Cleanser", type: "Cleanser", rating: 4.2 },
      { name: "Mad Hippie Vitamin C Serum", type: "Serum", rating: 4.1 },
      { name: "Kiehl's Ultra Facial Cream", type: "Moisturizer", rating: 4.3 },
    ],
  },
]

export default function DermaHubModernLanding() {
  const [selectedSkinType, setSelectedSkinType] = useState<SkinType | null>(null)
  const [showChatbot, setShowChatbot] = useState(false)

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50">
      {/* Header */}
      <header className="px-4 py-6 md:py-8">
        <div className="container mx-auto">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-rose-400 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">
                DermaHub
              </h1>
            </div>
            <p className="text-lg md:text-xl text-gray-600 max-w-2xl">
              Discover your perfect skincare routine with AI-powered recommendations tailored for your unique skin
            </p>
          </div>
        </div>
      </header>

      {/* Skin Type Selection Grid */}
      <section className="px-4 py-8">
        <div className="container mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-3">What's Your Skin Type?</h2>
            <p className="text-gray-600">Select your skin type to get personalized recommendations</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6 max-w-6xl mx-auto">
            {skinTypes.map((skinType) => (
              <Card
                key={skinType.id}
                className={`cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-xl border-2 ${
                  selectedSkinType?.id === skinType.id
                    ? "border-rose-400 shadow-lg ring-4 ring-rose-100"
                    : "border-gray-200 hover:border-rose-300"
                }`}
                onClick={() => setSelectedSkinType(skinType)}
              >
                <CardContent className="p-4">
                  <div className="aspect-square relative mb-4 rounded-xl overflow-hidden bg-gradient-to-br from-amber-100 to-orange-200">
                    <Image
                      src="/placeholder.svg?height=200&width=200"
                      alt={`${skinType.name} texture`}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                    <div className="absolute top-3 right-3 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center">
                      {skinType.icon}
                    </div>
                  </div>
                  <Button
                    variant={selectedSkinType?.id === skinType.id ? "default" : "outline"}
                    className={`w-full rounded-xl font-medium ${
                      selectedSkinType?.id === skinType.id
                        ? "bg-gradient-to-r from-rose-400 to-pink-500 hover:from-rose-500 hover:to-pink-600"
                        : "hover:bg-rose-50 hover:border-rose-300"
                    }`}
                  >
                    {skinType.label}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Personalized Results Section */}
      {selectedSkinType && (
        <section className="px-4 py-8 animate-in slide-in-from-bottom-4 duration-500">
          <div className="container mx-auto max-w-4xl">
            <Card className="border-0 shadow-2xl bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6 md:p-8">
                <div className="text-center mb-8">
                  <div className="flex items-center justify-center space-x-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-rose-400 to-pink-500 rounded-2xl flex items-center justify-center">
                      {selectedSkinType.icon}
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold text-gray-800">{selectedSkinType.name}</h3>
                  </div>
                  <p className="text-gray-600 text-lg">{selectedSkinType.description}</p>
                </div>

                <div className="grid md:grid-cols-2 gap-8">
                  {/* Characteristics */}
                  <div>
                    <h4 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                      Key Characteristics
                    </h4>
                    <div className="space-y-2">
                      {selectedSkinType.characteristics.map((char, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-rose-400 rounded-full" />
                          <span className="text-gray-600">{char}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Routine */}
                  <div>
                    <h4 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                      <Clock className="w-5 h-5 text-blue-500 mr-2" />
                      Daily Routine
                    </h4>
                    <div className="space-y-4">
                      <div>
                        <Badge variant="outline" className="mb-2 border-orange-200 text-orange-700">
                          Morning
                        </Badge>
                        <div className="space-y-1">
                          {selectedSkinType.routine.morning.map((step, index) => (
                            <div key={index} className="text-sm text-gray-600 flex items-center">
                              <span className="w-5 h-5 bg-orange-100 rounded-full flex items-center justify-center text-xs font-medium text-orange-600 mr-2">
                                {index + 1}
                              </span>
                              {step}
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2 border-purple-200 text-purple-700">
                          Evening
                        </Badge>
                        <div className="space-y-1">
                          {selectedSkinType.routine.evening.map((step, index) => (
                            <div key={index} className="text-sm text-gray-600 flex items-center">
                              <span className="w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center text-xs font-medium text-purple-600 mr-2">
                                {index + 1}
                              </span>
                              {step}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recommended Products */}
                <div className="mt-8">
                  <h4 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                    <Star className="w-5 h-5 text-yellow-500 mr-2" />
                    Recommended Products
                  </h4>
                  <div className="grid md:grid-cols-3 gap-4">
                    {selectedSkinType.products.map((product, index) => (
                      <Card key={index} className="border border-gray-200 hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <Badge variant="secondary" className="text-xs">
                              {product.type}
                            </Badge>
                            <div className="flex items-center space-x-1">
                              <Star className="w-3 h-3 text-yellow-400 fill-current" />
                              <span className="text-xs text-gray-600">{product.rating}</span>
                            </div>
                          </div>
                          <h5 className="font-medium text-gray-800 text-sm leading-tight">{product.name}</h5>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <div className="mt-8 text-center">
                  <Button className="bg-gradient-to-r from-rose-400 to-pink-500 hover:from-rose-500 hover:to-pink-600 text-white px-8 py-3 rounded-xl font-medium">
                    Get Full Personalized Plan
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Floating Chatbot */}
      <div className="fixed bottom-6 right-6 z-50">
        <div className="relative">
          {!showChatbot && (
            <div className="absolute -top-16 right-0 bg-white rounded-xl shadow-lg p-3 max-w-xs animate-in slide-in-from-bottom-2">
              <p className="text-sm text-gray-700 font-medium">Ask Derma AI anything about your skin!</p>
              <div className="absolute bottom-0 right-4 w-0 h-0 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-white"></div>
            </div>
          )}
          <Button
            onClick={() => setShowChatbot(!showChatbot)}
            className="w-14 h-14 rounded-full bg-gradient-to-r from-rose-400 to-pink-500 hover:from-rose-500 hover:to-pink-600 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
          >
            <MessageCircle className="w-6 h-6 text-white" />
          </Button>
        </div>
      </div>

      {/* Chatbot Interface */}
      {showChatbot && (
        <div className="fixed bottom-24 right-6 w-80 h-96 bg-white rounded-2xl shadow-2xl border border-gray-200 z-40 animate-in slide-in-from-bottom-4">
          <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-rose-400 to-pink-500 rounded-t-2xl">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-white">Derma AI</h4>
                <p className="text-xs text-white/80">Your skincare assistant</p>
              </div>
            </div>
          </div>
          <div className="p-4 h-64 overflow-y-auto">
            <div className="bg-gray-100 rounded-xl p-3 mb-4">
              <p className="text-sm text-gray-700">
                Hi! I'm Derma AI. I can help you with skincare questions, product recommendations, and routine advice.
                What would you like to know?
              </p>
            </div>
          </div>
          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Ask me anything..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
              <Button size="sm" className="bg-gradient-to-r from-rose-400 to-pink-500 rounded-xl">
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
